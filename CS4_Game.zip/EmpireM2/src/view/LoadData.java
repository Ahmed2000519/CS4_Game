package view;

public class LoadData {
	public static void loadData() {
		
	}
}
