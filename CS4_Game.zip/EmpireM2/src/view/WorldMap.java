package view;

import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JFrame;
/*
public class WorldMap extends Canvas {
	public void paint(Graphics g) {  
		  
        Toolkit t=Toolkit.getDefaultToolkit();  
        Image i=t.getImage("map.jpeg");  
        g.drawImage(i, 120,100,this);  
          
    } 
  public static void putmap() {
	  WorldMap m=new WorldMap();  
        JFrame f=new JFrame();  
        f.add(m);  
        f.setSize(1650,1080);  
        f.setExtendedState(f.getExtendedState() | JFrame.MAXIMIZED_BOTH);
        f.setVisible(true);
        
        
  }
}
*/