package exceptions;

@SuppressWarnings("serial")
public class FriendlyCityException extends ArmyException {

	public FriendlyCityException() {
		
	}

	public FriendlyCityException(String s) {
		super(s);
		
	}

}
