package units;

public enum Status {
IDLE,MARCHING,BESIEGING
}
